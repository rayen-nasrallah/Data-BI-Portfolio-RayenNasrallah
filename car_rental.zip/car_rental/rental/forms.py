# rental/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Booking, Car
from django.utils import timezone

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()
    first_name = forms.CharField(max_length=30)
    last_name = forms.CharField(max_length=30)
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class BookingForm(forms.ModelForm):
    pickup_location = forms.CharField(label="Lieu de prise en charge", widget=forms.TextInput(attrs={'placeholder': 'Ville, aéroport ou gare'}))
    return_location = forms.CharField(label="Lieu de retour", widget=forms.TextInput(attrs={'placeholder': 'Ville, aéroport ou gare'}))
    
    class Meta:
        model = Booking
        fields = ['pickup_date', 'pickup_time', 'return_date', 'return_time', 'pickup_location', 'return_location']
        widgets = {
            'pickup_date': forms.DateInput(attrs={'type': 'date'}),
            'return_date': forms.DateInput(attrs={'type': 'date'}),
            'pickup_time': forms.TimeInput(attrs={'type': 'time'}),
            'return_time': forms.TimeInput(attrs={'type': 'time'}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        pickup_date = cleaned_data.get('pickup_date')
        return_date = cleaned_data.get('return_date')
        
        if pickup_date and return_date:
            if pickup_date < timezone.now().date():
                raise forms.ValidationError("La date de prise en charge ne peut pas être dans le passé.")
            if return_date <= pickup_date:
                raise forms.ValidationError("La date de retour doit être après la date de prise en charge.")
            if (return_date - pickup_date).days > 30:
                raise forms.ValidationError("La durée de location ne peut pas dépasser 30 jours.")
        
        return cleaned_data