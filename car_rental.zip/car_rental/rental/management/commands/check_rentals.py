# rental/management/commands/check_rentals.py

from django.core.management.base import BaseCommand
from django.utils import timezone
from rental.models import Booking, Notification
from datetime import timedelta

class Command(BaseCommand):
    help = 'Vérifie les locations qui se terminent bientôt et envoie des notifications'
    
    def handle(self, *args, **kwargs):
        # Locations qui se terminent dans 1 jour
        soon = timezone.now().date() + timedelta(days=1)
        ending_bookings = Booking.objects.filter(
            return_date=soon,
            is_cancelled=False
        )
        
        for booking in ending_bookings:
            # Vérifier si une notification a déjà été envoyée
            if not Notification.objects.filter(
                user=booking.user,
                booking=booking,
                message__contains="se termine bientôt"
            ).exists():
                Notification.objects.create(
                    user=booking.user,
                    booking=booking,
                    message=f"Votre location de {booking.car.model} se termine bientôt. Date de retour: {booking.return_date}."
                )
                self.stdout.write(f"Notification envoyée à {booking.user.username}")
        
        self.stdout.write("Vérification des locations terminée.")