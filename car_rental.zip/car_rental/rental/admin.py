# rental/admin.py

from django.contrib import admin
from .models import Car, Booking, Notification
from django.utils.html import format_html

class CarAdmin(admin.ModelAdmin):
    list_display = ('model', 'car_type', 'price_per_day', 'available')
    list_filter = ('car_type', 'available')
    search_fields = ('model',)
    
    def image_tag(self, obj):
        return format_html('<img src="{}" width="100" />'.format(obj.image.url))
    
    image_tag.short_description = 'Image'
    readonly_fields = ('image_tag',)

class BookingAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'car', 'pickup_date', 'return_date', 'total_price', 'is_cancelled')
    list_filter = ('is_cancelled', 'pickup_date')
    search_fields = ('user__username', 'car__model')
    readonly_fields = ('created_at',)

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'booking', 'created_at', 'is_read')
    list_filter = ('is_read',)
    search_fields = ('user__username', 'message')

admin.site.register(Car, CarAdmin)
admin.site.register(Booking, BookingAdmin)
admin.site.register(Notification, NotificationAdmin)