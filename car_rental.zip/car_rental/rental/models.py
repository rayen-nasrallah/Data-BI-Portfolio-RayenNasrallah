# rental/models.py

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta

class Car(models.Model):
    CAR_TYPES = (
        ('ECO', 'Économique'),
        ('COM', 'Compacte'),
        ('SUV', 'SUV'),
        ('LUX', 'Luxe'),
        ('VAN', 'Minivan'),
    )
    
    model = models.CharField(max_length=100)
    car_type = models.CharField(max_length=3, choices=CAR_TYPES)
    price_per_day = models.DecimalField(max_digits=6, decimal_places=2)
    seats = models.PositiveSmallIntegerField()
    doors = models.PositiveSmallIntegerField()
    air_conditioning = models.BooleanField(default=True)
    transmission = models.CharField(max_length=10, choices=[('MAN', 'Manuelle'), ('AUT', 'Automatique')])
    available = models.BooleanField(default=True)
    image = models.ImageField(upload_to='car_images/')
    description = models.TextField(blank=True)
    
    def __str__(self):
        return f"{self.model} ({self.get_car_type_display()})"

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    car = models.ForeignKey(Car, on_delete=models.CASCADE)
    pickup_date = models.DateField()
    pickup_time = models.TimeField()
    return_date = models.DateField()
    return_time = models.TimeField()
    pickup_location = models.CharField(max_length=100)
    return_location = models.CharField(max_length=100)
    total_price = models.DecimalField(max_digits=8, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    is_cancelled = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Reservation #{self.id} - {self.car.model} par {self.user.username}"
    
    def is_active(self):
        return not self.is_cancelled and self.return_date >= timezone.now().date()
    
    def duration(self):
        return (self.return_date - self.pickup_date).days
    
    def save(self, *args, **kwargs):
        if not self.total_price:
            self.total_price = self.car.price_per_day * self.duration()
        super().save(*args, **kwargs)

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Notification pour {self.user.username}"