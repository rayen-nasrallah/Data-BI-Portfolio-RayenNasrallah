# rental/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import Car, Booking, Notification
from .forms import UserRegisterForm, BookingForm
from datetime import datetime, timedelta
from django.utils import timezone
from django.contrib.admin.views.decorators import staff_member_required
from socket import gaierror

def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            try:
                send_mail(
                    'Confirmation de réservation',
                    f'Votre réservation pour {car.model} a été enregistrée.',
                    'from@example.com',
                    [request.user.email],
                    fail_silently=False,
                )
                messages.success(request, 'Réservation confirmée! Un email a été envoyé.')
            except gaierror:
                messages.success(request, 'Réservation confirmée! (Email non envoyé - problème de connexion)')
            return redirect('my_bookings')
    else:
        form = BookingForm(initial={
            'pickup_date': datetime.now().date() + timedelta(days=1),
            'return_date': datetime.now().date() + timedelta(days=3),
            'pickup_time': '10:00',
            'return_time': '10:00'
        })
    
    return render(request, 'rental/car_detail.html', {'car': car, 'form': form})

@staff_member_required
def dashboard(request):
    cars = Car.objects.all().order_by('-id')
    bookings = Booking.objects.all().order_by('-created_at')
    return render(request, 'rental/dashboard.html', {
        'cars': cars,
        'bookings': bookings
    })

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'rental/my_bookings.html', {
        'bookings': bookings,
        'now': timezone.now().date()
    })
def car_list(request):
    cars = Car.objects.filter(available=True)
    return render(request, 'rental/car_list.html', {'cars': cars})

def home(request):
    cars = Car.objects.filter(available=True)[:3]
    return render(request, 'rental/home.html', {'cars': cars})

def car_list(request):
    cars = Car.objects.filter(available=True)
    return render(request, 'rental/car_list.html', {'cars': cars})

def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return redirect('login')
        
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.car = car
            booking.save()
            
            # Créer une notification
            Notification.objects.create(
                user=request.user,
                booking=booking,
                message=f"Votre réservation pour {car.model} a été confirmée."
            )
            
            # Envoyer un email de confirmation
            send_mail(
                'Confirmation de réservation',
                f'Votre réservation pour {car.model} du {booking.pickup_date} au {booking.return_date} a été confirmée.',
                settings.EMAIL_HOST_USER,
                [request.user.email],
                fail_silently=False,
            )
            
            messages.success(request, 'Votre réservation a été confirmée!')
            return redirect('my_bookings')
    else:
        initial_data = {
            'pickup_date': datetime.now().date() + timedelta(days=1),
            'return_date': datetime.now().date() + timedelta(days=3),
            'pickup_time': '10:00',
            'return_time': '10:00',
            'pickup_location': '',
            'return_location': '',
        }
        form = BookingForm(initial=initial_data)
    
    return render(request, 'rental/car_detail.html', {'car': car, 'form': form})

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'rental/my_bookings.html', {'bookings': bookings})

@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    if booking.pickup_date > datetime.now().date() and not booking.is_cancelled:
        booking.is_cancelled = True
        booking.save()
        
        # Créer une notification
        Notification.objects.create(
            user=request.user,
            booking=booking,
            message=f"Votre réservation pour {booking.car.model} a été annulée."
        )
        
        messages.success(request, 'Réservation annulée avec succès.')
    else:
        messages.error(request, 'Cette réservation ne peut pas être annulée.')
    
    return redirect('my_bookings')

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Compte créé pour {username}! Vous pouvez maintenant vous connecter.')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'rental/register.html', {'form': form})

@login_required
def dashboard(request):
    if not request.user.is_staff:
        return redirect('home')
    
    cars = Car.objects.all()
    bookings = Booking.objects.all().order_by('-created_at')
    return render(request, 'rental/dashboard.html', {'cars': cars, 'bookings': bookings})
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.shortcuts import render, redirect

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'rental/register.html', {'form': form})